#include <gtk/gtk.h>
void on_button1k_clicked (GtkWidget *widget , gpointer user_data);

void on_button2k_clicked (GtkWidget *widget , gpointer user_data);

void on_button3k_clicked (GtkWidget *widget , gpointer user_data);

void on_button4k_clicked (GtkWidget *widget , gpointer user_data);

void on_button5k_clicked (GtkWidget *widget , gpointer user_data);

void on_button6k_clicked (GtkWidget *widget , gpointer user_data);

void on_button7k_clicked (GtkWidget *widget , gpointer user_data);
void on_button8k_clicked (GtkWidget *widget , gpointer user_data);




void on_button9k_clicked (GtkWidget *widget , gpointer user_data);

void on_button10k_clicked (GtkWidget *widget , gpointer user_data);

void on_button11k_clicked (GtkWidget *widget , gpointer user_data);

void on_button12k_clicked (GtkWidget *widget , gpointer user_data);

void on_button13k_clicked (GtkWidget *widget , gpointer user_data);


void on_button15k_clicked (GtkWidget *widget , gpointer user_data);

void on_button16k_clicked (GtkWidget *widget , gpointer user_data);

void on_button17k_clicked (GtkWidget *button , gpointer user_data);

void on_button18k_clicked (GtkWidget *button , gpointer user_data);

void on_button19k_clicked (GtkWidget *widget , gpointer user_data);

void on_button20k_clicked (GtkWidget *button , gpointer user_data);

void on_button21k_clicked (GtkWidget *widget , gpointer user_data);








void
on_button23k_clicked                   (GtkWidget      *widget,
                                        gpointer         user_data);

void
on_button22k_clicked                   (GtkWidget       *widget,
                                        gpointer         user_data);



void
on_supprimer1k_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_validersuppression1k_clicked        (GtkWidget      *objet,
                                        gpointer         user_data);



void
on_retoursupf_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data);




void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_validh_clicked                      (GtkWidget      *widget,
                                        gpointer         user_data);

void
on_supprimh_clicked                    (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_affichh_clicked                     (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_retourgh_clicked                    (GtkWidget      *widget,
                                        gpointer         user_data);

void
on_bretour_clicked                     (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_validsuph_clicked                   (GtkWidget      *widget,
                                        gpointer         user_data);

void
on_retoursh_clicked                    (GtkWidget      *widget,
                                       gpointer         user_data);

void
on_retourrdvaffich_clicked      (GtkWidget *objet_graphique , gpointer user_data);


void
on_validmodif1_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_retourmodif_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_validrdv_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_modifrdv_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimrdv_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_affichrdv_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_validsuprdv_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_validmodifrdv1_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retourdispordv_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_retourdisp_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);



void
on_modiffich4k_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bmodifier11k_clicked                (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_retourmodifk_clicked                (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_modifhonorairek_clicked             (GtkWidget      *widget,
                                        gpointer         user_data);

void
on_validmodifhon1k_clicked             (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_rtourmodifhonk_clicked              (GtkWidget       *widget,
                                        gpointer         user_data);
