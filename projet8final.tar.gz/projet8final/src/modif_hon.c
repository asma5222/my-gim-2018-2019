#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif


#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gestionhonoraire.h"
#include "modif_hon.h"



void modiffier_fichehon(ficheh dh)//parametre mte3na
{
	FILE *f;
	FILE *ftemp;
	FILE *file_ptr;
	ficheh  x;
	f=fopen("/home/asmalaribi/Bureau/projet8final/src/honoraire.txt","r");
	ftemp=fopen("/home/asmalaribi/Bureau/projet8final/src/honoraire1.tmp","w");
	while(fscanf(f,"%s %s %s \n", x.numdecure, x.typedecure, x.honoraire)!=EOF)
	{
		if(strcmp(dh.numdecure,x.numdecure)==0)
		{
			fprintf(ftemp,"%s %s %s \n",dh.numdecure, dh.typedecure, dh.honoraire);
		}
		else
		{
			fprintf(ftemp,"%s %s %s  \n",x.numdecure, x.typedecure, x.honoraire);
		}
	}





	/*if (f!=NULL)
	{
    		while(fscanf(f,"%s %s %s\n",x.jour,x.debut,x.fin)!=EOF)//na9raw il fichier mte3na
    		{
      			if(strcmp(p.jour,x.jour)!=0)//ken il parametre different mil ligne na3mlou copie mak i ligne fil fichier ejdid
        			{fprintf(ftemp,"%s %s %s\n",x.jour,x.debut,x.fin);}

      			else//ken il parametre kima i ligne ili na9rawfeha nwaliw najoutiw i ligne iliejdida w na79rou le9dima mehech rajel
        			{fprintf(ftemp,"%s %s %s\n",p.jour,p.debut,p.fin);}//l ajout mta3 i ligne elmodifier fel fichier ijdid
         	}
	}*/
	fclose(f);
	fclose(ftemp);
	remove("/home/asmalaribi/Bureau/projet8final/src/honoraire.txt");//nfaskhou ilfichier lasleni 
	rename("/home/asmalaribi/Bureau/projet8final/src/honoraire1.tmp","/home/asmalaribi/Bureau/projet8final/src/honoraire.txt");//nranomiw il fichier ejdid besm li9dim bech ye5ou blastou
}
