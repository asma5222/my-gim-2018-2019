#include <gtk/gtk.h>
#include <stdio.h>

void supprimer1(char s1[20]);
