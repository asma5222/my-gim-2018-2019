#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "verifier.h"
#include "ajout.h"
#include "affichage.h"
#include "ajouut.h"
#include "affichage1.h"
#include "ajout2.h"
#include "affichage2.h"
#include "supprimer.h"
#include "supprimer1.h"
#include "modif.h"


char s1[20],s[20],Cinn[20];
GtkWidget *medecin;
void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *L;
GtkWidget *P;
GtkWidget *erreur;

GtkWidget *medecin;
GtkWidget *Login;
medecin=create_medecin();
int v;
char l[20] , p[20] ;

erreur=lookup_widget(objet_graphique,"label87");




L=lookup_widget(objet_graphique,"entry1");
P=lookup_widget(objet_graphique,"entry2");




strcpy(l,gtk_entry_get_text(GTK_ENTRY(L)));
strcpy(p,gtk_entry_get_text(GTK_ENTRY(P)));
v=verifier(l,p);


 if (v==2)
	{
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"Login")));
gtk_widget_show(medecin);

}
 else 
{
gtk_label_set_text(GTK_LABEL(erreur),"Erreur d'Authentification");
}
}




void
on_Profil_clicked                      (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *medecin;
GtkWidget *Profil;

Profil=create_Profil();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"medecin")));
gtk_widget_show(Profil);

}


void
on_Fiches__clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *medecin;
GtkWidget *Fiches;

Fiches=create_Fiches();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"medecin")));
gtk_widget_show(Fiches);

}


void
on_Deconnexion_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *medecin;
GtkWidget *Login;

Login=create_Login();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"medecin")));
gtk_widget_show(Login);
}


void
on_button2_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Parcourt;
GtkWidget *Fiches;

Parcourt=create_Parcourt();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Fiches")));
gtk_widget_show(Parcourt);

}


void
on_button3_clicked                     (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *Ajoutfiche;
GtkWidget *Fiches;

Ajoutfiche=create_Ajoutfiche();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Fiches")));
gtk_widget_show(Ajoutfiche);

}


void
on_button4_clicked                     (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *medecin;
GtkWidget *Fiches;

medecin=create_medecin();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Fiches")));
gtk_widget_show(medecin);

}



void
on_button6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_button7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *medecin;
GtkWidget *Parcourt;

medecin=create_medecin();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Parcourt")));
gtk_widget_show(medecin);

}


void
on_Valider_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Ajoutfiche;
Ajoutfiche = lookup_widget(button,"Ajoutfiche");
char Nom[20], Prenom[20], CIN[10],Poids[20],Etat[100];
Date d;
GtkWidget *jour,*mois,*annee,*a,*b,*c,*e,*f;
a=lookup_widget(button,"entry3");
b=lookup_widget(button,"entry4");
c=lookup_widget(button,"entry6");
e=lookup_widget(button,"entry5");
f=lookup_widget(button,"entry7");

jour=lookup_widget(button, "spinbutton1");
mois=lookup_widget(button, "spinbutton2");
annee=lookup_widget(button, "spinbutton3");

strcpy(Nom,gtk_entry_get_text(GTK_ENTRY(a)));
strcpy(Prenom,gtk_entry_get_text(GTK_ENTRY(b)));
strcpy(Poids,gtk_entry_get_text(GTK_ENTRY(c)));
strcpy(Etat,gtk_entry_get_text(GTK_ENTRY(e)));
strcpy(CIN,gtk_entry_get_text(GTK_ENTRY(f)));

d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
d.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));

ajouter(Nom,Prenom,CIN,d,Poids,Etat);

}


void
on_button9_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *medecin;
GtkWidget *Ajoutfiche;

medecin=create_medecin();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Ajoutfiche")));
gtk_widget_show(medecin);

}





void
on_button10_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *medecin;
GtkWidget *Profil;

medecin=create_medecin();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Profil")));
gtk_widget_show(medecin);
}


void
on_button11_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Fiches;
GtkWidget *Parcourt;

Fiches=create_Fiches();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Parcourt")));
gtk_widget_show(Fiches);
}


void
on_button12_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Fiches;
GtkWidget *Ajoutfiche;

Fiches=create_Fiches();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Ajoutfiche")));
gtk_widget_show(Fiches);
}


void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Disponibilite;
Disponibilite=lookup_widget(objet_graphique,"Disponibilite");
char lundi[20];
char mardi[20];
char mercredi[20];
char jeudi[20]; 
char vendredi[20];
char samedi[20];
sem S;

GtkWidget *combobox1;
GtkWidget *combobox7;
GtkWidget *combobox3;
GtkWidget *combobox4;
GtkWidget *combobox5;
GtkWidget *combobox6;
GtkWidget *Semaine;




combobox1=lookup_widget(objet_graphique,"combobox1");
combobox7=lookup_widget(objet_graphique,"combobox7");
combobox3=lookup_widget(objet_graphique,"combobox3");
combobox4=lookup_widget(objet_graphique,"combobox4");
combobox5=lookup_widget(objet_graphique,"combobox5");
combobox6=lookup_widget(objet_graphique,"combobox6");
Semaine=lookup_widget(objet_graphique,"spinbutton4");



strcpy(lundi,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(mardi,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox7)));
strcpy(mercredi,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)));
strcpy(jeudi,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox4)));
strcpy(vendredi,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox5)));
strcpy(samedi,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox6)));

S.Semaine=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Semaine));

ajouuter(S,lundi,mardi,mercredi,jeudi,vendredi,samedi);
}


void
on_button14_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *medecin;
GtkWidget *Disponibilite;

medecin=create_medecin();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Disponibilite")));
gtk_widget_show(medecin);
}


void
on_Disponibilite_clicked               (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *medecin;
GtkWidget *Disponibilite;

Disponibilite=create_Disponibilite();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"medecin")));
gtk_widget_show(Disponibilite);
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_button15_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Parcourt;
GtkWidget *treeview2;

Parcourt=lookup_widget(button,"Parcourt");
treeview2=lookup_widget(Parcourt,"treeview2");

afficher(treeview2);
}

void
on_button16_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Affichedispo;
GtkWidget *Disponibilite;

Affichedispo=create_Affichedispo();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Disponibilite")));
gtk_widget_show(Affichedispo);
}


void
on_button17_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *medecin;
GtkWidget *Affichedispo;

medecin=create_medecin();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Affichedispo")));
gtk_widget_show(medecin);
}


void
on_button18_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Affichedispo;
GtkWidget *Disponibilite;

Disponibilite=create_Disponibilite();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Affichedispo")));
gtk_widget_show(Disponibilite);
}


void
on_button19_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Affichedispo;
GtkWidget *treeview3;

Affichedispo=lookup_widget(button,"Affichedispo");
treeview3=lookup_widget(Affichedispo,"treeview3");

afficher1(treeview3);
}


void
on_button20_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Login;
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Login")));

}


void
on_button21_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Modifsuppplan;
GtkWidget *Affichedispo;

Modifsuppplan=create_Modifsuppplan();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Affichedispo")));
gtk_widget_show(Modifsuppplan);
}


void
on_button22_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *medecin;
GtkWidget *Rendezvous;

Rendezvous=create_Rendezvous();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"medecin")));
gtk_widget_show(Rendezvous);
}


void
on_button24_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Ajoutrendezvous;
GtkWidget *Rendezvous;

Ajoutrendezvous=create_Ajoutrendezvous();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Rendezvous")));
gtk_widget_show(Ajoutrendezvous);
}


void
on_button23_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Rendezvous;
GtkWidget *Afficherendezvous;

Afficherendezvous=create_Afficherendezvous();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Rendezvous")));
gtk_widget_show(Afficherendezvous);

}


void
on_button27_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Afficherendezvous;
GtkWidget *Rendezvous;

Rendezvous=create_Rendezvous();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Afficherendezvous")));
gtk_widget_show(Rendezvous);
}



void
on_button28_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Afficherendezvous;
GtkWidget *medecin;

medecin=create_medecin();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Afficherendezvous")));
gtk_widget_show(medecin);
}


void
on_button26_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_button29_clicked                    (GtkWidget       *objetgraphique,
                                        gpointer         user_data)
{
GtkWidget *Ajoutrendezvous;
Ajoutrendezvous=lookup_widget(objetgraphique,"Ajoutrendezvous");
char Nom[20],Prenom[20],CIN[20],Heure[100];

daate d;

GtkWidget *Jour,*Mois,*Annee,*q,*w,*x,*combobox8;

q=lookup_widget(objetgraphique,"entry8");
w=lookup_widget(objetgraphique,"entry9");
x=lookup_widget(objetgraphique,"entry10");
combobox8=lookup_widget(objetgraphique,"combobox8");


Jour=lookup_widget(objetgraphique,"spinbutton5");
Mois=lookup_widget(objetgraphique,"spinbutton6");
Annee=lookup_widget(objetgraphique,"spinbutton7");



strcpy(Nom,gtk_entry_get_text(GTK_ENTRY(q)));
strcpy(Prenom,gtk_entry_get_text(GTK_ENTRY(w)));
strcpy(CIN,gtk_entry_get_text(GTK_ENTRY(x)));
strcpy(Heure,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox8)));


d.Jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (Jour));
d.Mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (Mois));
d.Annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (Annee));


ajouter2(Nom,Prenom,CIN,d,Heure);


}

void
on_button31_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Ajoutrendezvous;
GtkWidget *Rendezvous;

Rendezvous=create_Rendezvous();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Ajoutrendezvous")));
gtk_widget_show(Rendezvous);
}


void
on_button30_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Ajoutrendezvous;
GtkWidget *medecin;

medecin=create_medecin();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Ajoutrendezvous")));
gtk_widget_show(medecin);
}


void
on_button32_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Rendezvous;
GtkWidget *medecin;

medecin=create_medecin();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Rendezvous")));
gtk_widget_show(medecin);
}


void
on_button25_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Afficherendezvous;
GtkWidget *treeview4;

Afficherendezvous=lookup_widget(button,"Afficherendezvous");
treeview4=lookup_widget(Afficherendezvous,"treeview4");

afficher2(treeview4);
}





void
on_button34_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Modifsuppplan;
GtkWidget *Confirmation;
GtkWidget *S1;

Confirmation=create_Confirmation();
gtk_widget_show(Confirmation);
S1=lookup_widget(button,"entry11");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(S1)));

}


void
on_button35_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_button36_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Modifsuppplan;
GtkWidget *medecin;

medecin=create_medecin();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Modifsuppplan")));
gtk_widget_show(medecin);
}


void
on_button37_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Modifsuppplan;
GtkWidget *Affichedispo;

Affichedispo=create_Affichedispo();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Modifsuppplan")));
gtk_widget_show(Affichedispo);
}


void
on_button38_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{


GtkWidget *Confirmation;
GtkWidget *Modifsuppplan;

Confirmation=lookup_widget(button,"Confirmation");

supprimer(s);
}


void
on_button39_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Confirmation;

gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Confirmation")));


}








void
on_button5_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Modifsuppfiche;
GtkWidget *Parcourt;

Modifsuppfiche=create_Modifsuppfiche();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Parcourt")));
gtk_widget_show(Modifsuppfiche);
}


void
on_button40_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data)
{



Modifsuppfiche=lookup_widget(obj,"Modifsuppfiche");


input1=lookup_widget(obj,"entry12");
strcpy(Cinn,gtk_entry_get_text(GTK_ENTRY(input1)));

gtk_widget_hide(GTK_WIDGET(lookup_widget(obj,"Modifsuppfiche")));
Modiffiche=create_Modiffiche();
gtk_widget_show(Modiffiche);





}


void
on_button41_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Modifsuppfiche;
GtkWidget *Confirmation2;
GtkWidget *S2;

Confirmation2=create_Confirmation2();
gtk_widget_show(Confirmation2);
S2=lookup_widget(button,"entry12");
strcpy(s1,gtk_entry_get_text(GTK_ENTRY (S2)));
}


void
on_button42_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Modifsuppfiche;
GtkWidget *medecin;

medecin=create_medecin();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Modifsuppfiche")));
gtk_widget_show(medecin);
}


void
on_button44_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{


GtkWidget *Confirmation2;
GtkWidget *Modifsupppfiche;

Confirmation2=lookup_widget(button,"Confirmation2");


supprimer1(s1);
}


void
on_button45_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Modifsuppfiche;
GtkWidget *Confirmation2;


gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Confirmation2")));

}


void
on_button43_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Modifsuppfiche;
GtkWidget *Parcourt;

Parcourt=create_Parcourt();
gtk_widget_hide(GTK_WIDGET(lookup_widget(button,"Modifsuppfiche")));
gtk_widget_show(Parcourt);
}


void
on_button46_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data)
{

GtkWidget *input2,*input3,*input4,*input5,*input8,*input9;


char Nom[20];
char Prenom[20];
char CIN[20];
char Date[20];


char Poids[20];
char Etat[20];
Modiffiche=lookup_widget(obj,"Modiffiche");

input2=lookup_widget(obj,"entry13");
input3=lookup_widget(obj,"entry14");
input4=lookup_widget(obj,"entry15");
input5=lookup_widget(obj,"entry18");


input8=lookup_widget(obj,"entry16");
input9=lookup_widget(obj,"entry17");




strcpy(Nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(Prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(CIN,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(Date,gtk_entry_get_text(GTK_ENTRY(input5)));


strcpy(Poids,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(Etat,gtk_entry_get_text(GTK_ENTRY(input9)));


modifier(Nom,Prenom,CIN,Date,Poids,Etat,Cinn);






}


void
on_button47_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data)
{
char nom1[20];
char prenom1[20];
char cin1[20];
char jour1[20];


char poids1[20];
char etat1[20];
Modiffiche=lookup_widget(obj,"Modiffiche");
output1=lookup_widget(obj,"entry13");
output2=lookup_widget(obj,"entry14");
output3=lookup_widget(obj,"entry15");
output4=lookup_widget(obj,"entry18");


output7=lookup_widget(obj,"entry16");
output8=lookup_widget(obj,"entry17");
FILE* f;
f=fopen("/home/yosrdgd/Desktop/sousou/medecin.txt","r");
if (f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s\n",nom1,prenom1,cin1,jour1,poids1,etat1)!=EOF)
{if (strcmp(cin1,Cinn)==0)

{
gtk_entry_set_text(GTK_ENTRY(output1),nom1);
gtk_entry_set_text(GTK_ENTRY(output2),prenom1);
gtk_entry_set_text(GTK_ENTRY(output3),cin1);
gtk_entry_set_text(GTK_ENTRY(output4),jour1);


gtk_entry_set_text(GTK_ENTRY(output7),poids1);
gtk_entry_set_text(GTK_ENTRY(output8),etat1);
}
}
}
fclose(f);
}

