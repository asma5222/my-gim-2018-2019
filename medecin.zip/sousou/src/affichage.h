#include <gtk/gtk.h>

typedef struct

{

char jour[20];
char mois[20];
char annee[20];
}date;


void afficher(GtkWidget *liste);

