#include "verif.h"
#include<gtk/gtk.h>



char verif(daate d,char Heure[]);
{
FILE*f;
int x=0;

int jour1;
int mois1;
int annee1;
char heure[20];


f=fopen("rendez-vous","r");
if (f!=NULL)

{while (fscanf(f,%


