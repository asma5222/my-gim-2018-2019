#include <gtk/gtk.h>

void sup_honoraire(char hon[20]);
