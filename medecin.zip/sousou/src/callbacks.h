#include <gtk/gtk.h>

GtkWidget *Modifsuppfiche;
GtkWidget *Modiffiche,*fixed16,*window1;
GtkWidget *input1,*output1,*output2,*output3,*output4,*output5,*output6,*output7,*output8;
void
on_button1_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_Profil_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fiches__clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Deconnexion_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget      *button,
                                        gpointer         user_data);



void
on_button6_clicked                     (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget      *button,
                                        gpointer         user_data);

void
on_Valider_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);



void
on_button10_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);

void
on_Disponibilite_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button26_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button28_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button27_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);




void
on_button29_clicked                    (GtkWidget       *objetgraphique,
                                        gpointer         user_data);

void
on_button31_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button30_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button32_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);



void
on_button25_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);



void
on_button34_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button35_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button36_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button37_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button38_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button39_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);



void
on_button5_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button40_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_button41_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button42_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button44_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button45_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);



void
on_button43_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button46_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_button47_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);
