#include "supprimer1.h"
#include <string.h>
#include <stdio.h>


void supprimer1(char s1[20])// a dekhla en parametre 
{
	char Nom[20];
	char Prenom[20];
	char cin[20];
	char Poids[20];
	char Etat[20];
	char date[20];
	

	FILE *l;
	FILE *t;
	l=fopen("/home/yosrdgd/Desktop/sousou/medecin.txt","r");
	t=fopen("file.txt","a");
	while (fscanf(l,"%s %s %s %s %s %s\n",Nom,Prenom,cin,date,Poids,Etat)!=EOF)//na9raw mil fichier temporaire
	{
		if (strcmp(s1,cin)!=0)//ken la valeur ili na9raw fiha differente mil parametre ya3ni ncopiw i ligne fel fichier e jdid
		{
			fprintf(t,"%s %s %s %s %s %s\n",Nom,Prenom,cin,date,Poids,Etat);//copie de la ligne fel fichier jdid
		}
	}
	fclose(l);
	fclose(t);
	remove("/home/yosrdgd/Desktop/sousou/medecin.txt");//nfas5ou il fichier li9dim
	rename("file.txt","/home/yosrdgd/Desktop/sousou/medecin.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blas
}
