int verifier(char L[] , char P[]);
