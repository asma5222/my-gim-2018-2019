#include <stdio.h>
#include <stdlib.h>
#include "ajout2.h"
#include <string.h>

void ajouter2(char Nom[20],char Prenom[20],char CIN[20],daate d,char Heure[100])
{
	FILE *f;
	f=fopen("/home/yosrdgd/Desktop/sousou/rendezvous.txt","a");
	
	if (f!=NULL)
	{fprintf(f,"%s %s %s %d/%d/%d %s\n",Nom,Prenom,CIN,d.Jour,d.Mois,d.Annee,Heure);}
fclose(f);
	
}
