#include "suprim2.h"


void supprim1kk(char cin[20])// a dekhla en parametre 
{
	char a1[20];
	char b1[20];
	char c1[20];
        char d1[20];
        char e1[20];

	FILE *fK1;
	FILE *tk;
	fK1=fopen("/home/asmalaribi/Bureau/projet8final/src/fiche.txt","r");
	tk=fopen("/home/asmalaribi/Bureau/projet8final/src/fiche1.tmp","a+");
	while (fscanf(fK1," %s %s %s %s %S ",a1,b1,c1,d1,e1)!=EOF)//na9raw mil fichier temporaire
	{
		if (strcmp(cin,a1)!=0)//ken la valeur ili na9raw fiha differente mil parametre ya3ni ncopiw i ligne fel fichier e jdid
		{
			fprintf(tk," %s %s %s %s %s \n",a1,b1,c1,d1,e1);//copie de la ligne fel fichier jdid
		}
	}
	fclose(fK1);
	fclose(tk);
	remove("/home/asmalaribi/Bureau/projet8final/src/fiche.txt");//nfas5ou il fichier li9dim
	rename("/home/asmalaribi/Bureau/projet8final/src/fiche1.tmp","/home/asmalaribi/Bureau/projet8final/src/fiche.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
}

