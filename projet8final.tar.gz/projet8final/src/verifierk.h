int verifk(char login[],char password[]);
