#include <gtk/gtk.h>

typedef struct
{

char numdecure[20];
char typedecure[200];
char honoraire[30];

}ficheh ;

void modiffier_fichehon(ficheh dh);
