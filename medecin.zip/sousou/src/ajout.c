#include <stdio.h>
#include <stdlib.h>
#include "ajout.h"
#include <string.h>

void ajouter (char Nom[],char Prenom[],char CIN[],Date d,char Poids[],char Etat[])
{
	FILE *f;
	f=fopen("medecin.txt","a");
	
	if (f!=NULL)
	{fprintf(f,"%s %s %s %d/%d/%d %s %s\n",Nom,Prenom,CIN,d.jour,d.mois,d.annee,Poids,Etat);}
fclose(f);
	
}
