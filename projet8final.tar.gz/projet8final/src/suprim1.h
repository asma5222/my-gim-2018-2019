#include <gtk/gtk.h>

void supprim1k(char cin[20]);
