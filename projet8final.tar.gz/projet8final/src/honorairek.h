#include <gtk/gtk.h>

typedef struct
{

char Num[20];
char Honoraire[30];
char Typedecure[200];


} Honoraires ;

void ajouter_honoraire(Honoraires h);
void afficher_honoraire(GtkWidget *liste);
