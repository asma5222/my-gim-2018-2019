typedef struct
{
int jour;
int mois;
int annee;
}Date;

void ajouter (char Nom[],char Prenom[],char CIN[],Date d,char Poids[],char Etat[]);
