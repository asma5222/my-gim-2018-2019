#include <stdio.h>
#include <gtk/gtk.h>

typedef struct
{
int Semaine;
}sem;

void ajouuter(sem S,char lundi[],char mardi[],char mercredi[],char jeudi[],char vendredi[],char samedi[]);
