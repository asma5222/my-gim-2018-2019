void
on_modifrdvk_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *dispok1;
GtkWidget *modifrdv;
dispok1=lookup_widget(objet_graphique,"dispok1");
modifrdv=create_modifrdv();
gtk_widget_show(modifrdv);

}
void
on_validmodifrdv1_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *jour1;
GtkWidget *mois1;
GtkWidget *annee1;
GtkWidget *heure1;
GtkWidget *num1;



jour1=lookup_widget(objet_graphique,"spin1k");
mois1=lookup_widget(objet_graphique,"spin2k");
annee1=lookup_widget(objet_graphique,"spin3k");
heure1=lookup_widget(objet_graphique,"spin4k");
num1=lookup_widget(objet_graphique,"spin5k");
 
jour1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour1));
mois1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois1));
annee1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee1));
heure1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (heure1));
num1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (num1));
modif(num1,heure1,jour1,mois1,annee1);
}
void
on_retourdispordv_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *modifrdv, *dispok1;

modifrdv=lookup_widget(objet_graphique,"modifrdv");


gtk_widget_destroy(modifrdv);
dispok1=create_dispok1();
gtk_widget_show(dispok1);


}
