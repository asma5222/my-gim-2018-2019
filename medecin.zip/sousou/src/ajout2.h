typedef struct
{
int Jour;
int Mois;
int Annee;
}daate;

void ajouter2(char Nom[],char Prenom[],char CIN[],daate d,char Heure[]);
