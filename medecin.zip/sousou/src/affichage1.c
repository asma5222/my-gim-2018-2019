#include <stdio.h>
#include <string.h>
#include "affichage1.h"
#include <gtk/gtk.h>


enum
{
SEMAINE,
LUNDI,
MARDI,
MERCREDI,
JEUDI,
VENDREDI,
SAMEDI,
COLUMNS
};


void afficher1(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

int Semaine;
char Lundi[20];
char Mardi[20];
char Mercredi[10];
char Jeudi[20];
char Vendredi[100];
char Samedi[20];


store=NULL;

FILE *f;

//store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Semaine",renderer,"text",SEMAINE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Lundi",renderer,"text",LUNDI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Mardi",renderer,"text",MARDI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Mercredi",renderer,"text",MERCREDI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Jeudi",renderer,"text",JEUDI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Vendredi",renderer,"text",VENDREDI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Samedi",renderer,"text",SAMEDI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


store=gtk_list_store_new(COLUMNS, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
}
f=fopen("/home/yosrdgd/Desktop/sousou/disponible.txt","r");

if(f==NULL)
{
return;
}

else
{

f=fopen("/home/yosrdgd/Desktop/sousou/disponible.txt","a+");

	while(fscanf(f,"%d %s %s %s %s %s %s\n",&Semaine,Lundi,Mardi,Mercredi,Jeudi,Vendredi,Samedi)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store, &iter ,SEMAINE,Semaine,LUNDI,Lundi,MARDI,Mardi,MERCREDI,Mercredi, JEUDI,Jeudi ,VENDREDI,Vendredi,SAMEDI,Samedi, -1);
}

fclose(f);

gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}






