#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "verifierk.h"
#include "personnek.h"
#include "suprim2.h"
#include "support.h"
#include <string.h>
#include "reservation.h"
#include "gestionhonoraire.h"
#include "supprimerh.h"
#include "ajoutrdv.h"
#include "modif_fich.h"
#include "modif_hon.h"
void
on_button1k_clicked                    (GtkWidget      *widget,
                                        gpointer         user_data)
{int vk;
GtkWidget *login1k;
GtkWidget *password1k;
GtkWidget *role1k;
GtkWidget *espacek;
GtkWidget *logink;
GtkWidget *erreurk;
espacek=create_espacek();
erreurk=create_erreurk();


char username[20];
char password[20];
int role;
login1k=lookup_widget(widget ,"entry1k");
password1k=lookup_widget(widget ,"entry2k");
//role=lookup_widget(widget,"role")

strcpy(username,gtk_entry_get_text(GTK_ENTRY(login1k)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(password1k)));
vk = verifk (username , password);
if (vk==1){
gtk_widget_show(espacek);
gtk_widget_destroy(logink);}
else
{gtk_widget_show(erreurk);
gtk_widget_destroy(logink);}}




void
on_button2k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *espacek;
GtkWidget *notificationk;
notificationk=create_notificationk();
espacek=lookup_widget(widget,"espacek");
gtk_widget_show(notificationk);
gtk_widget_destroy(espacek);}


void
on_button9k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *notificationk;
GtkWidget *notadmink;
notadmink=create_notadmink();
notificationk=lookup_widget(widget,"notificationk");
gtk_widget_show(notadmink);
gtk_widget_destroy(notificationk);}
void
on_button10k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *notificationk;
GtkWidget *notmedecink;
notmedecink=create_notmedecink();
notificationk=lookup_widget(widget,"notificationk");
gtk_widget_show(notmedecink);
gtk_widget_destroy(notificationk);}
void
on_button11k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *notificationk;
GtkWidget *notadhk;
notadhk=create_notadhk();
notificationk=lookup_widget(widget,"notificationk");
gtk_widget_show(notadhk);
gtk_widget_destroy(notificationk);}
void
on_button3k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *espacek;
GtkWidget *ajoufichk;
ajoufichk=create_ajoufichk();
espacek=lookup_widget(widget,"espacek");
gtk_widget_show(ajoufichk);
gtk_widget_destroy(espacek);}
void
on_button17k_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{



PersonneK pK;

GtkWidget *input1K, *input2K,*input3K,*input4K,*input5K;
GtkWidget *ajoufichk;

ajoufichk=lookup_widget(objet,"ajoufichk");

input1K=lookup_widget(objet,"entry3k");
input2K=lookup_widget(objet,"entry4k");
input3K=lookup_widget(objet,"entry5k");
input4K=lookup_widget(objet,"entry6k");
input5K=lookup_widget(objet,"entry7k");


strcpy(pK.cinK,gtk_entry_get_text(GTK_ENTRY(input1K)));
strcpy(pK.nomK,gtk_entry_get_text(GTK_ENTRY(input2K)));
strcpy(pK.prenomK,gtk_entry_get_text(GTK_ENTRY(input3K)));
strcpy(pK.ageK,gtk_entry_get_text(GTK_ENTRY(input4K)));
strcpy(pK.typedecureK,gtk_entry_get_text(GTK_ENTRY(input5K)));



ajouter_personneK(pK);


}


void
on_button18k_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *ajoufichk;
GtkWidget *affichfichk;
GtkWidget *treeview1k;

ajoufichk=lookup_widget(objet,"ajoufichk");


gtk_widget_destroy(ajoufichk);
affichfichk=lookup_widget(objet,"affichfichk");
affichfichk=create_affichfichk();

gtk_widget_show(affichfichk);
      

treeview1k=lookup_widget(affichfichk,"treeview1k");

afficher_personneK(treeview1k);


}
void
on_button4k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *espacek;
GtkWidget *dispok1;
dispok1=create_dispok1();
espacek=lookup_widget(widget,"espacek");
gtk_widget_show(dispok1);
gtk_widget_destroy(espacek);}
void
on_button5k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *espacek;
GtkWidget *agendak;
agendak=create_agendak();
espacek=lookup_widget(widget,"espacek");
gtk_widget_show(agendak);
gtk_widget_destroy(espacek);}
void
on_button6k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *espacek;
GtkWidget *logink;
logink=create_logink();
espacek=lookup_widget(widget,"espacek");
gtk_widget_show(logink);
gtk_widget_destroy(espacek);}
void
on_button7k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *logink;
GtkWidget *espacek;
logink=create_logink();
espacek=lookup_widget(widget,"espacek");
gtk_widget_show(logink);
gtk_widget_destroy(espacek);}
void
on_button12k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *notificationk;
GtkWidget *logink;
logink=create_logink();
notificationk=lookup_widget(widget,"notificationk");
gtk_widget_show(logink);
gtk_widget_destroy(notificationk);}
void
on_button13k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *espacek;
GtkWidget *notificationk;
espacek=create_espacek();
notificationk=lookup_widget(widget,"notificationk");
gtk_widget_show(espacek);
gtk_widget_destroy(notificationk);}
void
on_button21k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *notadmink;
GtkWidget *notificationk;
notificationk=create_notificationk();
notadmink=lookup_widget(widget,"notadmink");
gtk_widget_show(notificationk);
gtk_widget_destroy(notadmink);}
void
on_button22k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *notmedecink;
GtkWidget *notificationk;
notificationk=create_notificationk();
notmedecink=lookup_widget(widget,"notmedecink");
gtk_widget_show(notificationk);
gtk_widget_destroy(notmedecink);}
void
on_button23k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *notadhk;
GtkWidget *notificationk;
notificationk=create_notificationk();
notadhk=lookup_widget(widget,"notadhk");
gtk_widget_show(notificationk);
gtk_widget_destroy(notadhk);}
void
on_button20k_clicked (GtkWidget *objet , gpointer user_data){
GtkWidget *affichfichk;
GtkWidget *ajoufichk;
ajoufichk=create_ajoufichk();
affichfichk=lookup_widget(objet,"affichfichk");
gtk_widget_show(ajoufichk);
gtk_widget_destroy(affichfichk);}
void
on_button15k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *logink;
GtkWidget *ajoufichk;
logink=create_logink();
ajoufichk=lookup_widget(widget,"ajoufichk");
gtk_widget_show(logink);
gtk_widget_destroy(ajoufichk);}
void
on_button16k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *espacek;
GtkWidget *ajoufichk;
espacek=create_espacek();
ajoufichk=lookup_widget(widget,"ajoufichk");
gtk_widget_show(espacek);
gtk_widget_destroy(ajoufichk);}
void
on_button19k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *logink;
GtkWidget *affichfichk;
logink=create_logink();
affichfichk=lookup_widget(widget,"affichfichk");
gtk_widget_show(logink);
gtk_widget_destroy(affichfichk);}
void
on_button8k_clicked (GtkWidget *widget , gpointer user_data){
GtkWidget *logink;
GtkWidget *erreurk;
logink=create_logink();
erreurk=lookup_widget(widget,"erreurk");
gtk_widget_show(logink);
gtk_widget_destroy(erreurk);}





void
on_validersuppression1k_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)

{
char cin[20];

	GtkWidget *cin1k;
	GtkWidget *recherchesup1k;
        
        

        recherchesup1k=lookup_widget(objet,"recherchesup1k");

	cin1k=lookup_widget(objet,"entrycin1k");

	strcpy(cin,gtk_entry_get_text(GTK_ENTRY(cin1k)));
	
	supprim1k(cin);
        


        
     
      

        
}



void
on_supprimer1k_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data)
{       GtkWidget *recherchesup1k;
	GtkWidget *ajoufichk;
	

	ajoufichk=lookup_widget(objet,"ajoufichk");
	gtk_widget_destroy(ajoufichk);
	recherchesup1k=create_recherchesup1k();
	gtk_widget_show(recherchesup1k);
	
}






void
on_retoursupf_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{ GtkWidget *recherchesup1k;
	GtkWidget *ajoufichk;
	

	recherchesup1k=lookup_widget(objet,"recherchesup1k");
	gtk_widget_destroy(recherchesup1k);
	ajoufichk=create_ajoufichk();
	gtk_widget_show(ajoufichk);

}






void
on_validh_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{Honoraire h;

GtkWidget *input1, *input2,*input3;
GtkWidget *agendak;

agendak=lookup_widget(objet,"agendak");

input1=lookup_widget(objet,"numcu");
input2=lookup_widget(objet,"typcurek");
input3=lookup_widget(objet,"honorairk");



strcpy(h.numdecure,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h.typedecure,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(h.honoraire,gtk_entry_get_text(GTK_ENTRY(input3)));


ajouter_honoraire(h);

}


void
on_supprimh_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *agendak, *supprimergh;

agendak=lookup_widget(objet,"agendak");


gtk_widget_destroy(agendak);
supprimergh=create_supprimergh();
gtk_widget_show(supprimergh);


}


void
on_affichh_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *agendak;
GtkWidget *affichgh;
GtkWidget *treeviewh;

agendak=lookup_widget(objet,"agendak");


gtk_widget_destroy(agendak);
affichgh=lookup_widget(objet,"affichgh");
affichgh=create_affichgh();

gtk_widget_show(affichgh);
      

treeviewh=lookup_widget(affichgh,"treeviewh");

afficher_honoraire(treeviewh); 
}


void
on_retourgh_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *agendak, *espacek;

agendak=lookup_widget(objet,"agendak");


gtk_widget_destroy(agendak);
espacek=create_espacek();
gtk_widget_show(espacek);

}


void
on_bretour_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *agendak, *affichgh;

affichgh=lookup_widget(objet,"affichgh");


gtk_widget_destroy(affichgh);
agendak=create_agendak();
gtk_widget_show(agendak);

}


void
on_validsuph_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data)
{char hon[20];

	GtkWidget *hon1;
	GtkWidget *supprimergh;
        
        

        supprimergh=lookup_widget(objet,"supprimergh");

	hon1=lookup_widget(objet,"nsupk");

	strcpy(hon,gtk_entry_get_text(GTK_ENTRY(hon1)));
	
	sup_honoraire(hon);

}


void
on_retoursh_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *agendak, *supprimergh;

supprimergh=lookup_widget(objet,"supprimergh");


gtk_widget_destroy(supprimergh);
agendak=create_agendak();
gtk_widget_show(agendak);


}








void
on_validrdv_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *heure;
GtkWidget *num;
GtkWidget *dispok1;
date d;
jour=lookup_widget(objet_graphique,"spinbutton1k");
mois=lookup_widget(objet_graphique,"spinbutton2k");
annee=lookup_widget(objet_graphique,"spinbutton3k");
heure=lookup_widget(objet_graphique,"spinbutton4k");
num=lookup_widget(objet_graphique,"spinbutton5k");
 
d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));
d.heure=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (heure));
d.num=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (num));

if (verif(d.num)==0)
ajoute(d);

}



void
on_supprimrdv_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *dispok1;
GtkWidget *wsuprdv;
dispok1=lookup_widget(objet_graphique,"dispok1");
gtk_widget_destroy(dispok1);
wsuprdv=create_wsuprdv();
gtk_widget_show(wsuprdv);

}


void
on_affichrdv_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 int num=0;
GtkWidget *affichrdv1;
GtkWidget *dispok1;
GtkWidget *treeviewrdv;

dispok1=lookup_widget(objet_graphique,"dispok1");
gtk_widget_destroy(dispok1);
affichrdv1=create_affichrdv1();
gtk_widget_show(affichrdv1);
treeviewrdv=lookup_widget(affichrdv1,"treeviewrdv");
afficher(treeviewrdv);
}


void
on_validsuprdv_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *wsuprdv;
GtkWidget *num1;
int x;
num1=lookup_widget(objet_graphique,"rechsupprdv");
num1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (num1));
supprim(num1);

}








void
on_retourrdvaffich_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *affichrdv1, *dispok1;

affichrdv1=lookup_widget(objet_graphique,"affichrdv1");


gtk_widget_destroy(affichrdv1);
dispok1=create_dispok1();
gtk_widget_show(dispok1);


}





void
on_retourdisp_clicked       (GtkWidget       *objet_graphique,gpointer         user_data)           
                           
{
GtkWidget *espacek, *dispok1;

dispok1=lookup_widget(objet_graphique,"dispok1");


gtk_widget_destroy(dispok1);
espacek=create_espacek();
gtk_widget_show(espacek);
}

void
on_modiffich4k_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *validmodifierfichk, *ajoufichk;

ajoufichk=lookup_widget(objet_graphique,"ajoufichk");


gtk_widget_destroy(ajoufichk);
validmodifierfichk=create_validmodifierfichk();
gtk_widget_show(validmodifierfichk);

}


void
on_bmodifier11k_clicked                (GtkWidget       *widget,
                                        gpointer         user_data)
{
	fiche d;

	GtkWidget *input11k,*input22k,*input33k,*input44k,*input55k;
	GtkWidget *validmodifierfichk;

	validmodifierfichk=lookup_widget(widget,"validmodifierfichk");

	input11k=lookup_widget(widget,"mb11");
	input22k=lookup_widget(widget,"mb21");
	input33k=lookup_widget(widget,"mb31");
        input44k=lookup_widget(widget,"mb41");
        input55k=lookup_widget(widget,"mb51");

	strcpy(d.cin,gtk_entry_get_text(GTK_ENTRY(input11k)));
	strcpy(d.nom,gtk_entry_get_text(GTK_ENTRY(input22k)));
	strcpy(d.prenom,gtk_entry_get_text(GTK_ENTRY(input33k)));
        strcpy(d.age,gtk_entry_get_text(GTK_ENTRY(input44k)));
	strcpy(d.typedecure,gtk_entry_get_text(GTK_ENTRY(input55k)));
	
	
	modiffier_fiche(d);
}


void
on_retourmodifk_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *validmodifierfichk, *ajoufichk;

validmodifierfichk=lookup_widget(objet_graphique,"validmodifierfichk");


gtk_widget_destroy(validmodifierfichk);
ajoufichk=create_ajoufichk();
gtk_widget_show(ajoufichk);

}


void
on_modifhonorairek_clicked             (GtkWidget       *widget,
                                        gpointer         user_data)
{GtkWidget *agendak,*fenetre_modif_hon;
agendak=lookup_widget(widget,"agendak");


gtk_widget_destroy(agendak);
fenetre_modif_hon=create_fenetre_modif_hon();
gtk_widget_show(fenetre_modif_hon);

}


void
on_validmodifhon1k_clicked             (GtkWidget       *widget,
                                        gpointer         user_data)
{ficheh dh;

	GtkWidget *input1hk,*input2hk,*input3hk;
	GtkWidget *fenetre_modif_hon;

	fenetre_modif_hon=lookup_widget(widget,"fenetre_modif_hon");

	input1hk=lookup_widget(widget,"hk1");
	input2hk=lookup_widget(widget,"hk2");
	input3hk=lookup_widget(widget,"hk3");
        

	strcpy(dh.numdecure,gtk_entry_get_text(GTK_ENTRY(input1hk)));
	strcpy(dh.typedecure,gtk_entry_get_text(GTK_ENTRY(input2hk)));
	strcpy(dh.honoraire,gtk_entry_get_text(GTK_ENTRY(input3hk)));
  
	
	
	modiffier_fichehon(dh);

}


void
on_rtourmodifhonk_clicked              (GtkWidget       *widget,
                                        gpointer         user_data)

{GtkWidget *fenetre_modif_hon,*agendak;
fenetre_modif_hon=lookup_widget(widget,"fenetre_modif_hon");
gtk_widget_destroy(fenetre_modif_hon);
agendak=create_agendak();
gtk_widget_show(agendak);

}


void
on_retourendez2_clicked                (GtkWidget       *widget,
                                        gpointer         user_data)
{GtkWidget *wsuprdv,*dispok1;
wsuprdv=lookup_widget(widget,"wsuprdv");
gtk_widget_destroy(wsuprdv);
dispok1=create_dispok1();
gtk_widget_show(dispok1);


}


void
on_mRDV_clicked                        (GtkWidget       *widget,
                                        gpointer         user_data)
{
GtkWidget *modifierunrdv,*dispok1;
dispok1=lookup_widget(widget,"dispok1");
gtk_widget_destroy(dispok1);
modifierunrdv=create_modifierunrdv();
gtk_widget_show(modifierunrdv);

}


void
on_validunmodif_clicked                (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *jour1;
GtkWidget *mois1;
GtkWidget *annee1;
GtkWidget *heure1;
GtkWidget *num1;



jour1=lookup_widget(objet_graphique,"jour1");
mois1=lookup_widget(objet_graphique,"mois1");
annee1=lookup_widget(objet_graphique,"annee1");
heure1=lookup_widget(objet_graphique,"heure1");
num1=lookup_widget(objet_graphique,"num1");
 
jour1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour1));
mois1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois1));
annee1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee1));
heure1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (heure1));
num1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (num1));
modif(num1,heure1,jour1,mois1,annee1);


}


void
on_retoumodifunrdv_clicked             (GtkWidget       *widget,
                                        gpointer         user_data)
{
GtkWidget *dispok1,*modifierunrdv;
modifierunrdv=lookup_widget(widget,"modifierunrdv");
gtk_widget_destroy(modifierunrdv);
dispok1=create_dispok1();
gtk_widget_show(dispok1);
}

