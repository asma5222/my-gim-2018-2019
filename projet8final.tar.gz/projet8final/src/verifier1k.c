#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "verifier1k.h"
int verifk1(char cinin[])
{
	FILE *fk1;
	char cin[20];
	
	int role;
fk1=fopen("/home/asmalaribi/Projets/user.txtk","r");
if(fk1!=NULL)
{
	while(fscanf(fk1,"%s %d",cin,&role)!=EOF)
	{
		if(strcmp(cin)==0) 
{
return(role);
}
}
return 0;
}
fclose(fk1);
} 
