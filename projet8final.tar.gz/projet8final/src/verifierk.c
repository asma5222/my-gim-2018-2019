#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "verifierk.h"
int verifk(char login[],char passwordentryk[])
{
	FILE *fk;
	char username[20];
	char password[20];
	int role;
fk=fopen("/home/asmalaribi/Projets/user.txt","r");
if(fk!=NULL)
{
	while(fscanf(fk,"%s %s %d",username,password,&role)!=EOF)
	{
		if((strcmp(login,username)==0) && strcmp(passwordentryk,password)==0)
{
return(role);
}
}
return 0;
}
fclose(fk);
} 
