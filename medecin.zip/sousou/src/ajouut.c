#include <stdio.h>
#include <stdlib.h>
#include "ajouut.h"
#include <string.h>

void ajouuter(sem S,char lundi[],char mardi[],char mercredi[],char jeudi[],char vendredi[],char samedi[])

{
	FILE *f;
	f=fopen("/home/yosrdgd/Desktop/sousou/disponible.txt","a");
	
	if (f!=NULL)
	{fprintf(f,"%d %s %s %s %s %s %s\n",S.Semaine,lundi,mardi,mercredi,jeudi,vendredi,samedi);}
fclose(f);
	
}
