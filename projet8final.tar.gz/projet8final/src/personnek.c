#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




#include <stdio.h>
#include <string.h>
#include "personnek.h"
#include <gtk/gtk.h>

enum   
{       
        CINK,
        NOMK,
	PRENOMK,
        AGEK,
        TYPEDECUREK,
        COLUMNS
};

//Ajouter une personne

void ajouter_personneK(PersonneK pK)
{

 FILE *fK1;
  fK1=fopen("/home/asmalaribi/Bureau/projet8final/src/fiche.txt","a+");
  if(fK1!=NULL) 
  {
  fprintf(fK1,"%s %s %s %s %s \n",pK.cinK,pK.nomK,pK.prenomK,pK.ageK,pK.typedecureK);
  fclose(fK1);

}

}


//Afficher une personne


void afficher_personneK(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char nomK [30];
	char prenomK [30];
	char ageK[30] ;
	char typedecureK[200];
        char cinK[30];
        store=NULL;

       FILE *fK1;
	
	store = gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  cinK", renderer, "text",CINK, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" nomK", renderer, "text",NOMK, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  prenomK", renderer, "text",PRENOMK, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  ageK", renderer, "text",AGEK, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  typedecureK", renderer, "text",TYPEDECUREK, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

               
	
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	fK1 = fopen("/home/asmalaribi/Bureau/projet8final/src/fiche.txt", "r");
	
	if(fK1==NULL)
	{

		return;
	}		
	else 

	{ fK1 = fopen("/home/asmalaribi/Bureau/projet8final/src/fiche.txt", "a+");
              while(fscanf(fK1,"%s %s %s %s %s \n",cinK,nomK,prenomK,ageK,typedecureK)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, CINK, cinK, NOMK, nomK, PRENOMK, prenomK,AGEK,ageK,TYPEDECUREK,typedecureK, -1); 
		}
		fclose(fK1);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}




