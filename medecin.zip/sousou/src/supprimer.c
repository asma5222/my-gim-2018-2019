#include "supprimer.h"
#include <string.h>
#include <stdio.h>


void supprimer(char s[20])// a dekhla en parametre 
{
	char Sem[20];
	char Lundi[20];
	char Mardi[20];
	char Mercredi[20];
	char Jeudi[20];
	char Vendredi[20];
	char Samedi[20];
	

	FILE *l;
	FILE *t;
	l=fopen("/home/yosrdgd/Desktop/sousou/disponible.txt","r");
	t=fopen("/home/yosrdgd/Desktop/sousou/disponible.tmp","a+");
	while (fscanf(l,"%s %s %s %s %s %s %s\n",Sem,Lundi,Mardi,Mercredi,Jeudi,Vendredi,Samedi)!=EOF)//na9raw mil fichier temporaire
	{
		if (strcmp(s,Sem)!=0)//ken la valeur ili na9raw fiha differente mil parametre ya3ni ncopiw i ligne fel fichier e jdid
		{
			fprintf(t,"%s %s %s %s %s %s %s\n",Sem,Lundi,Mardi,Mercredi,Jeudi,Vendredi,Samedi);//copie de la ligne fel fichier jdid
		}
	}
	fclose(l);
	fclose(t);
	remove("/home/yosrdgd/Desktop/sousou/disponible.txt");//nfas5ou il fichier li9dim
	rename("/home/yosrdgd/Desktop/sousou/disponible.tmp","/home/yosrdgd/Desktop/sousou/disponible.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
}
