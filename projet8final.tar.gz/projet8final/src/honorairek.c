#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




#include <stdio.h>
#include <string.h>
#include "honorairek.h"
#include <gtk/gtk.h>

enum   
{       
        NUMK,
        HONORAIRE,
	TYPE,
        TYPEDECURE,
        COLUMNS
};

//Ajouter honoraire

void ajouter_honoraire(Honoraires h)
{

 FILE *fh;
  fh=fopen("/home/asmalaribi/Projets/projet8final/src/honoraires.txt","a+");
  if(fh!=NULL) 
  {
  fprintf(fh,"%s %s %s \n",h.Num,h.Honoraire,h.Typedecure);
  fclose(fh);

}

}


//Afficher honoraire


void afficher_honoraire(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char Num [20];
	char Honoraire [30];
	char Typedecure[200];
        
        store=NULL;

       FILE *fh;
	
	store = gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Num", renderer, "text",NUMK, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Typedecure", renderer, "text",TYPEDECURE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  Honoraire", renderer, "text",HONORAIRE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING);

	fh = fopen("/home/asmalaribi/Projets/projet8final/src/honoraires.txt", "r");
	
	if(fh==NULL)
	{

		return;
	}		
	else 

	{ fh = fopen("/home/asmalaribi/Projets/projet8final/src/honoraires.txt", "a+");
              while(fscanf(fh,"%s %s %s  \n",Num,Typedecure,Honoraire)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,NUMK , Num, TYPEDECURE, Typedecure, Honoraire, HONORAIRE, -1); 
		}
		fclose(fh);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}





