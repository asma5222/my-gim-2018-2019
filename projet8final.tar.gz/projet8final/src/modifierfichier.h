#include <gtk/gtk.h>
void modifier_fiche(char cin[],char nom[],char prenom[],char age[],char typedecure[]);
