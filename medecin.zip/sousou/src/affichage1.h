#include <gtk/gtk.h>

typedef struct

{

int Semaine;
}Semaine;


void afficher1(GtkWidget *liste);
