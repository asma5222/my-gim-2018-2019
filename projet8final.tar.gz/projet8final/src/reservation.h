#ifndef reservation_H_INCLUDED	
#define reservation_H_INCLUDED
#include "reservation.h"
typedef struct
{
int jour;
int mois;
int annee;
}Date;
typedef struct
{
char num[50];
char bloc;
Date dt_res;// -1/-1/-1 si non réserver
int hr_resr;//1 si matin 2 si aprem -1 sinon réserver
}ReservationSalle;

int tableau_salle_Reserver(ReservationSalle tab[50]);
int verifier_resrever(ReservationSalle sa);
int tableau_salle_disponible(char nom_salle[100][50],char bloc,Date dt_resr,int hr_resr);
void reserver_salle(ReservationSalle s);

#endif
