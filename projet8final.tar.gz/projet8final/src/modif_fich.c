#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif


#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "personnek.h"
#include "modif_fich.h"



void modiffier_fiche(fiche d)//parametre mte3na
{
	FILE *f;
	FILE *ftemp;
	FILE *file_ptr;
	fiche  x;
	f=fopen("/home/asmalaribi/Bureau/projet8final/src/fiche.txt","r");
	ftemp=fopen("/home/asmalaribi/Bureau/projet8final/src/fiche2.tmp","w");
	while(fscanf(f,"%s %s %s %s %s\n", x.cin, x.nom, x.prenom,x.age,x.typedecure)!=EOF)
	{
		if(strcmp(d.cin,x.cin)==0)
		{
			fprintf(ftemp,"%s %s %s %s %s\n",d.cin, d.nom, d.prenom,d.age,d.typedecure);
		}
		else
		{
			fprintf(ftemp,"%s %s %s %s %s \n",x.cin, x.nom, x.prenom,x.age,x.typedecure);
		}
	}





	/*if (f!=NULL)
	{
    		while(fscanf(f,"%s %s %s\n",x.jour,x.debut,x.fin)!=EOF)//na9raw il fichier mte3na
    		{
      			if(strcmp(p.jour,x.jour)!=0)//ken il parametre different mil ligne na3mlou copie mak i ligne fil fichier ejdid
        			{fprintf(ftemp,"%s %s %s\n",x.jour,x.debut,x.fin);}

      			else//ken il parametre kima i ligne ili na9rawfeha nwaliw najoutiw i ligne iliejdida w na79rou le9dima mehech rajel
        			{fprintf(ftemp,"%s %s %s\n",p.jour,p.debut,p.fin);}//l ajout mta3 i ligne elmodifier fel fichier ijdid
         	}
	}*/
	fclose(f);
	fclose(ftemp);
	remove("/home/asmalaribi/Bureau/projet8final/src/fiche.txt");//nfaskhou ilfichier lasleni 
	rename("/home/asmalaribi/Bureau/projet8final/src/fiche2.tmp","/home/asmalaribi/Bureau/projet8final/src/fiche.txt");//nranomiw il fichier ejdid besm li9dim bech ye5ou blastou
}
