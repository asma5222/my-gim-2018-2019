#include <stdio.h>
#include "modif.h"
#include <string.h>

void modifier(char Nom[],char Prenom[],char CIN[],char Date[],char Poids[],char Etat[],char amodifer[])
{
char nom[20];
char prenom[20];
char cin[20];
char date[20];
char poids[20];
char etat[20];
char amodifier[20];

FILE *f;
FILE *f2;
f=fopen("/home/yosrdgd/Desktop/sousou/medecin.txt","r");
f2=fopen("/home/yosrdgd/Desktop/sousou/medecin1.txt","w"); 
if (f!=NULL)
{
if (f2!=NULL)

{ 
     while (fscanf(f,"%s %s %s %s %s %s\n",nom,prenom,cin,date,poids,etat)!=EOF)
    { 
    if(strcmp(amodifier,cin)!=0)
    {
    fprintf(f2,"%s %s %s %s %s %s\n",nom,prenom,cin,date,poids,etat);
     }
else {
	fprintf(f2,"%s %s %s %s %s %s\n",Nom,Prenom,amodifier,Date,Poids,Etat);
     }
     }
     }}
fclose(f);
fclose(f2);

remove("/home/yosrdgd/Desktop/sousou/medecin.txt") ;
rename ("/home/yosrdgd/Desktop/sousou/medecin1.txt" , "/home/yosrdgd/Desktop/sousou/medecin.txt") ;
}
