int verifk1(char cin[]);
