#include <gtk/gtk.h>

typedef struct

{

char Jour[20];
char Mois[20];
char Annee[20];
}Daate;


void afficher2(GtkWidget *liste);
