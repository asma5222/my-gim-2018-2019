#include <stdio.h>
#include <string.h>
#include "affichage2.h"
#include <gtk/gtk.h>


enum
{
NOM,
PRENOM,
CIN,
DATE,
HEURE,
COLUMNS
};


void afficher2(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char Nom[20];
char Prenom[20];
char cin[10];
char Heure[20];
char date[20];


/*f=fopen("medecin.txt","r");

	while(fscanf(f,"%s %s %s %s/%s/%s %s %s\n",Nom,Prenom,CIN,v.jour,v.mois,v.annee,Poids,Etat)!=EOF)
{
z=strcat(v.jour,"/");
x=strcat(z,v.mois);
y=strcat(x,"/");

Date_de_naissance=strcat(x,v.annee);
}
fclose(f);*/
store=NULL;

FILE *f;

//store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Heure",renderer,"text",HEURE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);




store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
}
f=fopen("/home/yosrdgd/Desktop/sousou/rendezvous.txt","r");

if(f==NULL)
{
return;
}

else
{

f=fopen("/home/yosrdgd/Desktop/sousou/rendezvous.txt","a+");

	while(fscanf(f,"%s %s %s %s %s\n",Nom,Prenom,cin,date,Heure)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store, &iter , NOM ,Nom ,PRENOM, Prenom ,CIN, cin ,DATE, date,HEURE,Heure, -1);
}

fclose(f);

gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}





