#include <gtk/gtk.h>

typedef struct
{

char cinK[20];
char nomK[20];
char prenomK[30];
char ageK[30];
char typedecureK[200];


} PersonneK ;

void ajouter_personneK(PersonneK pK);
void afficher_personneK(GtkWidget *liste);

