#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "reservation.h"

int main()
{
char nom_salle[100][100];
char bloc='A';
Date dt_resr;
int i;
dt_resr.jour=19;
dt_resr.mois=11;
dt_resr.annee=2018;
int hr_resr=1;
int n=tableau_salle_disponible(nom_salle, bloc, dt_resr, hr_resr);


for(i=0;i<n;i++)
{
printf("%s\n",nom_salle[i]);
}

return 0;
}

