#include "supprimerh.h"


void sup_honoraire(char hon[20])// a dekhla en parametre 
{
	char ah[20];
	char bh[30];
	char ch[30];

	FILE *l;
	FILE *t;
	l=fopen("/home/asmalaribi/Bureau/projet8final/src/honoraire.txt","r");
	t=fopen("/home/asmalaribi/Bureau/projet8final/src/honoraire.tmp","a+");
	while (fscanf(l,"%s %s %s ",ah,bh,ch)!=EOF)//na9raw mil fichier temporaire
	{
		if (strcmp(hon,ah)!=0)//ken la valeur ili na9raw fiha differente mil parametre ya3ni ncopiw i ligne fel fichier e jdid
		{
			fprintf(t,"%s %s %s\n",ah,bh,ch);//copie de la ligne fel fichier jdid
		}
	}
	fclose(l);
	fclose(t);
	remove("/home/asmalaribi/Bureau/projet8final/src/honoraire.txt");//nfas5ou il fichier li9dim
	rename("/home/asmalaribi/Bureau/projet8final/src/honoraire.tmp","/home/asmalaribi/Bureau/projet8final/src/honoraire.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
}
