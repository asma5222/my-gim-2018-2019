#include <gtk/gtk.h>
#include <stdio.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "verifier.h"
#include <string.h>

int verifier(char L[] , char P[]){
char ch1[20];
char ch2[20];
int r=0 ; 

FILE * f;
f=fopen("/home/yosrdgd/Desktop/sousou/src/login.txt","r");


if (f!=NULL)
{

while(fscanf(f,"%s %s %d" , ch1 , ch2 ,&r)!=EOF)
{if ((strcmp(ch1,L)==0) && (strcmp(ch2,P)==0))

return r; }
}

fclose(f);
return -1;
}
