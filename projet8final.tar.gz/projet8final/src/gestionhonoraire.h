#include <gtk/gtk.h>

typedef struct
{

char numdecure[20];

char typedecure[200];
char honoraire[30];



}Honoraire;

void ajouter_honoraire(Honoraire h);
void afficher_honoraire(GtkWidget *liste);

