typedef struct
{
int Jour;
int Mois;
int Annee;
}daate;

char verif(date d,char Heure);
