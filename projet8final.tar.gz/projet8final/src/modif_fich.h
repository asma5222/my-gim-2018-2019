#include <gtk/gtk.h>

typedef struct
{

char cin[20];
char nom[20];
char prenom[30];
char age[30];
char typedecure[200];
}fiche ;

void modiffier_fiche(fiche d);
