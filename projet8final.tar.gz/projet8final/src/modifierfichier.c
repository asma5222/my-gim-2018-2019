#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




#include <stdio.h>
#include <string.h>
#include "modifierfichier.h"
#include <gtk/gtk.h>
void modifier_fiche(char cin[],char nom[],char prenom[],char age[],char typedecure[])
{char cin[20];
 char nom[30];
char prenom[30];
char age[30];
char typedecure[200];

FILE* f;
FILE* m;
f=fopen("/home/asmalaribi/Projets/projet8final/src/utilisateur.txtK","r");
m=fopen("/home/asmalaribi/Projets/projet8final/src/utilisateurmodif.txtK","a+");
while(fscanf(f,"%s %s %s %s %s",cin,nom,prenom,age,typedecure)!=EOF)
{if((strcmp(cin,cinn)==0))
   fprintf(m,"%s %s %s %s %s \n",cin,nom,prenom,age,typedecure);
else
fprintf(m,"%s %s %s %s %s \n",cin,nom,prenom,age,typedecure);
}
fclose(f);
fclose(f);
rename("/home/asmalaribi/Projets/projet8final/src/utilisateurmodif.txtK","/home/asmalaribi/Projets/projet8final/src/utilisateur.txtK")

