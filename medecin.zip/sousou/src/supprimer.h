#include <gtk/gtk.h>
#include <stdio.h>

void supprimer(char s[20]);
