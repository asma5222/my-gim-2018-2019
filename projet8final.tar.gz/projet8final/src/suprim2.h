#include <gtk/gtk.h>

void supprim1kk(char cin[20]);
