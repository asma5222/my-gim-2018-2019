#include <stdio.h>



void modifier(char Nom[20],char Prenom[20],char CIN[20],char Date[20],char Poids[20],char Etat[20],char amodifier[20]);


